class Empresa {
  const nombreEmpresa
  const cuit
  var empleados = []
  
  method montoBrutoTotal() = empleados.sum(
    { empleado => empleado.sueldoBruto() }
  )
  
  method montoRetenidoTotal() = empleados.sum(
    { empleado => empleado.retenciones() }
  )
  
  method montoNetoTotal() = empleados.sum({ empleado => empleado.sueldoNeto() })
  
  method liquidarSueldos() = empleados.map(
    { empleado => empleado.generarRecibo() }
  )
}

class Empleado {
  var nombreEmpleado
  var direccionEmpleado
  var estadoCivil
  const fechaNacimiento
  var sueldoBasico
  
  method edad() {
    var edad = new Date().year() - fechaNacimiento.year()
    if ((new Date().month() < fechaNacimiento.month()) || ((new Date().month() == fechaNacimiento.month()) && (new Date().day() < fechaNacimiento.day()))) {
      edad -= 1
    }
    return edad
  }
  
  method sueldoBruto() = sueldoBasico
  
  method retenciones() = self.retencionPorObraSocial() + self.retencionPorJubilacion()
  
  method retencionPorObraSocial() = self.sueldoBruto() * 0.1
  
  method retencionPorJubilacion()
  
  method sueldoNeto() = self.sueldoBruto() - self.retenciones()
  
  method desgloseCompleto() = (self.totalesDesglosados() + self.desgloseDeSueldoBruto()) + self.desgloseDeRetenciones()
  
  method totalesDesglosados() = [
    "Sueldo bruto = " + self.sueldoBruto().toString(),
    "Retenciones = " + self.retenciones().toString(),
    "Sueldo neto = " + self.sueldoNeto().toString()
  ]
  
  method desgloseDeSueldoBruto() = [
    "Calculo de sueldo bruto. ",
    "  Sueldo basico = " + sueldoBasico.toString()
  ]
  
  method desgloseDeRetenciones() = [
    "Calculo de retenciones. ",
    "  Retencion por Obra Social = " + self.retencionPorObraSocial().toString(),
    "  Retencion por jubilacion = " + self.retencionPorJubilacion().toString()
  ]
  
  method generarRecibo() = new ReciboDeHaberes(
    nombreEnRecibo = nombreEmpleado,
    direccion = direccionEmpleado,
    fechaDeEmision = new Date(),
    sueldoBruto = self.sueldoBruto(),
    sueldoNeto = self.sueldoNeto(),
    desgloseDeConceptos = self.desgloseCompleto()
  )
}

class EmpleadoDePlanta inherits Empleado {
  var cantDeHijos
  var antiguedad
  
  override method sueldoBruto() = super() + self.salarioFamiliar()
  
  override method desgloseDeSueldoBruto() = super() + [
    "  Saldo familiar:",
    "    Asignacion por hijos = " + self.sueldoPorHijos().toString(),
    "    Asignacion por conyuge = " + self.sueldoPorConyuge().toString(),
    "    Asignacion por antiguedad = " + self.sueldoPorAntiguedad().toString()
  ]
  
  method salarioFamiliar() = (self.sueldoPorHijos() + self.sueldoPorConyuge()) + self.sueldoPorAntiguedad()
  
  method sueldoPorHijos() = cantDeHijos * 150
  
  method sueldoPorConyuge() = if (estadoCivil == "prometide") 100 else 0
  
  method sueldoPorAntiguedad() = antiguedad * 50
  
  method retencionPorHijos() = cantDeHijos * 20
  
  override method retencionPorObraSocial() = super() + self.retencionPorHijos()
  
  override method retencionPorJubilacion() = self.sueldoBruto() * 0.15
}

class EmpleadoTemporario inherits Empleado {
  var fechaDeFinDeDesignacion
  var horasExtra
  
  override method sueldoBruto() = super() + self.sueldoPorHorasExtra()
  
  method sueldoPorHorasExtra() = 40 * horasExtra
  
  method retencionPorHorasExtra() = 5 * horasExtra
  
  method retencionPorEdad() = if (self.edad() > 50) 25 else 0
  
  override method retencionPorObraSocial() = super() + self.retencionPorEdad()
  
  override method retencionPorJubilacion() = (self.sueldoBruto() * 0.1) + self.retencionPorHorasExtra()
}

class ReciboDeHaberes {
  const nombreEnRecibo
  const direccion
  const fechaDeEmision = new Date()
  const sueldoBruto
  const sueldoNeto
  const desgloseDeConceptos
}